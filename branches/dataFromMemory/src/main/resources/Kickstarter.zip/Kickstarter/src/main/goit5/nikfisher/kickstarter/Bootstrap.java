package goit5.nikfisher.kickstarter;


import goit5.nikfisher.kickstarter.model.QuoteGenerate;
import goit5.nikfisher.kickstarter.streams.ConsoleIO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Random;


public class Bootstrap {

	final static Logger LOGGER = LoggerFactory.getLogger(Bootstrap.class);

	public static void main(String[] args){
		LOGGER.info("Start program.");
		Main app = new Main(new ConsoleIO(), new QuoteGenerate(new Random()));
		app.run();
		LOGGER.info("Finished program.");
	}
}