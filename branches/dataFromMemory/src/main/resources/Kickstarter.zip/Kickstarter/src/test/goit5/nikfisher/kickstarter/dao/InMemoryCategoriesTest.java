package goit5.nikfisher.kickstarter.dao;

public class InMemoryCategoriesTest /*xtends CategoriesTest*/ {

//    @Override
//    Categories getCategories() {
//        return new InMemoryCategories();
//    }
}
