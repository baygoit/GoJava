package goit5.nikfisher.kickstarter.dao;


public class InFileprojectsTest /*extends ProjectsTest*/ {
//
//
//    @Override
//    Projects getProjects() {
//        return new InFileProjects("projects_test.txt");
//    }
//
//    @After
//    public void cleanup(){
//        new File("projects_test.txt").delete();
//    }
}
