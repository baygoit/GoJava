package goit5.nikfisher.kickstarter.dao;

public class InFileCategoryTest /*extends CategoriesTest*/ {

//    @Override
//    Categories getCategories() {
//        return new InFileCategories("categories_test.txt");
//    }
//
//    @After
//    public void cleanup(){
//        new File("categories_test.txt").delete();
//    }
}
