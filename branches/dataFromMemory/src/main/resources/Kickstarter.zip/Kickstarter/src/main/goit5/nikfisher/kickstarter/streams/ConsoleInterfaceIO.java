package goit5.nikfisher.kickstarter.streams;

public interface ConsoleInterfaceIO {

    String consoleScanString();

    int consoleScanInt();

    void println(String a);

    void print(String a);

}
